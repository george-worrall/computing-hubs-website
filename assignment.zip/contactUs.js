document.addEventListener("DOMContentLoaded", function() {
    const form = document.getElementById("contact-form");
    const successMessage = document.getElementById("success-message");

    form.addEventListener("submit", function(event) {
        event.preventDefault(); // Prevent actual submission

        const name = document.getElementById("full-name").value.trim();
        const email = document.getElementById("email").value.trim();
        const subject = document.getElementById("subject").value.trim();
        const message = document.getElementById("message").value.trim();

        if (!name || !email || !subject || !message) {
            alert("Please fill in all fields.");
            return;
        }

        // Show success message
        successMessage.style.display = "block";

        // Clear the form
        form.reset();
    });
});

