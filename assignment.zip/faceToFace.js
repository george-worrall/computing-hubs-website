'use strict';

document.addEventListener("DOMContentLoaded", () => {
    fetch("faceToFace.json")
        .then(response => response.json())
        .then(data => {
            const tableBody = document.querySelector("tbody");
            tableBody.innerHTML = "";  // Clear any old content to avoid duplication
            
            data.forEach(course => {
                const row = document.createElement("tr");
                row.innerHTML = `
                    <td>${course.hubName}</td>
                    <td><a href="${course.all}" target="_blank" class="btn btn-primary">Book Now</a></td>
                    <td><a href="${course.secondary}" target="_blank" class="btn btn-primary">Book Now</a></td>
                    <td><a href="${course.primary}" target="_blank" class="btn btn-primary">Book Now</a></td>
                    <td><a href="${course.ks3AndGCSE}" target="_blank" class="btn btn-primary">Book Now</a></td>
                `;
                tableBody.appendChild(row);
            });
        })
        .catch(error => console.error("Error loading Face-to-Face data:", error));
});