document.addEventListener("DOMContentLoaded", function () {
  const events = [
      { name: 'ITT & ECT webinar series: AI and computing teaching', date: '12th March, 16:00-17:00', location: 'Online', bookingLink: 'https://www.eventbrite.co.uk/e/itt-ect-webinar-series-ai-and-computing-teaching-tickets-1000187597027?aff=ebdsoporgprofile' },
      { name: 'Programming - Errors, Testing, Tracing', date: '12th March, 17:00-18:30', location: 'Online', bookingLink: 'https://isaaccomputerscience.org/events/20250312_booster_programming_errors_testing_tracing?examBoard=all&stage=all' },
      { name: 'Functional Programming', date: '13th March, 17:00-18:30', location: 'Online', bookingLink: 'https://isaaccomputerscience.org/events/20250313_booster_functional_programming?examBoard=all&stage=all' },
      { name: 'Networks:Communication & Connections', date: '17th March, 17:00-18:30', location: 'Online', bookingLink: 'https://isaaccomputerscience.org/events/20250317_booster_networks_communication_connections?examBoard=all&stage=all' },
      { name: 'I Belong Enrichment workshop: movement-controlled light (KS2) - girls only', date: '18th March, 09:15-12:00', location: 'North Holmes Road Canterbury CT1 1QU', bookingLink: 'https://www.eventbrite.co.uk/e/i-belong-enrichment-workshop-movement-controlled-light-ks2-girls-only-tickets-1139655322749?aff=ebdsoporgprofile' },
      { name: 'Careers in Tech Day with TCS (KS3/11-14)', date: '2nd April, 09:30-14:30', location: '1 Harrison Way Royal Leamington Spa CV31 3HJ', bookingLink: 'https://www.eventbrite.co.uk/e/careers-in-tech-day-with-tcs-ks311-14-tickets-1104524314959?aff=ebdsoporgprofile' },
  ];

  function populateEvents() {
      const tableBody = document.getElementById('event-table-body'); // Corrected ID selection
      tableBody.innerHTML = ''; // Clear any previous content

      events.forEach(event => {
          const row = document.createElement('tr');

          // Create table cells
          row.innerHTML = `
              <td>${event.name}</td>
              <td>${event.date}</td>
              <td>${event.location}</td>
              <td><a href="${event.bookingLink}" class="book-now-button" target="_blank">Book Now</a></td>
          `;

          tableBody.appendChild(row);
      });
  }

  populateEvents(); // Call function when page loads
});
