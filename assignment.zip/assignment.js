let currentIndex = 0;

function moveSlide(step) {
    const slides = document.querySelectorAll('.carousel-images img');
    currentIndex += step;

    if (currentIndex >= slides.length) {
        currentIndex = 0;
    } else if (currentIndex < 0) {
        currentIndex = slides.length - 1;
    }

    const newTransformValue = -currentIndex * 100;
    document.querySelector('.carousel-images').style.transform = `translateX(${newTransformValue}%)`;
}

document.addEventListener("DOMContentLoaded", function() {
  const dropdownBtn = document.querySelector('.dropdown-btn');
  const dropdownContent = document.querySelector('.dropdown-content');

  // Toggle dropdown visibility on click
  dropdownBtn.addEventListener('click', function() {
      dropdownContent.style.display = dropdownContent.style.display === 'flex' ? 'none' : 'flex';
  });

  // Fetch the events from JSON
  fetch('events.json')
      .then(response => response.json())
      .then(events => {
          events.forEach(event => {
              const eventCard = document.createElement('div');
              eventCard.classList.add('event-card');
              eventCard.innerHTML = `
                  <img src="${event.image}" alt="${event.name}">
                  <h3>${event.name}</h3>
                  <p>${event.date} 
                  <p>${event.description}</p>
              `;
              dropdownContent.appendChild(eventCard);
          });
      })
      .catch(error => console.error('Error fetching event data:', error));
});

document.addEventListener('DOMContentLoaded', () => {
  fetch('remoteCourses.json')
      .then(response => {
          if (!response.ok) {
              throw new Error(`HTTP error! Status: ${response.status}`);
          }
          return response.json();
      })
      .then(data => {
          const tableBody = document.querySelector("tbody");
          tableBody.innerHTML = "";

          data.forEach(course => {
              const row = `<tr>
                  <td>${course.code}</td>
                  <td>${course.title}</td>
                  <td>${course.duration}</td>
                  <td><a href="${course.link}" target="_blank" class="btn btn-primary btn-sm">Book Now</a></td>
              </tr>`;
              tableBody.innerHTML += row;
          });
      })
      .catch(error => console.error("Error loading JSON data:", error));
});

document.querySelector(".dropdown-btn").addEventListener("click", function () {
    document.querySelector(".dropdown-content").classList.toggle("show");
});

// Close dropdown when clicking outside
window.addEventListener("click", function (event) {
    if (!event.target.matches(".dropdown-btn")) {
        document.querySelector(".dropdown-content").classList.remove("show");
    }
});
